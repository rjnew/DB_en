﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Data.SqlClient;

using System.Data.OleDb;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    string runSql(string sqlstr)
    {
        //part 1: connect db
        SqlConnection conn;
        string connstr = "Data Source=.;Initial Catalog=sc;Integrated Security=True";
        //string connstr2 = ConfigurationManager.ConnectionStrings["scConnectionString"].ToString();
        conn = new SqlConnection(connstr);
        conn.Open();

        //p2: execute sql statement, get resultset
        SqlCommand cmd;
        SqlDataReader dr;
        try
        {
            cmd = new SqlCommand(sqlstr, conn);
            dr = cmd.ExecuteReader();
        }
        catch (Exception e)
        {

            return e.Message;
        }
        //p3: output data in special format
        int colnum = dr.FieldCount;
        if (dr.HasRows == false) return "No available tuple!";

        string str = "";

        while (dr.Read())
        {
            for (int i = 0; i < colnum; i++)
            {
                string s1 = dr.GetValue(i).ToString().Trim();                 
                str +=s1+",";
            }
            str += "\n";
        }
        return str;

    }

    string runSql2(string sqlstr)   //for access
    {
        //part 1: connect db
        OleDbConnection conn;
        string connstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\sc2.mdb;Persist Security Info=True";//访问本地access
        conn = new OleDbConnection(connstr);
        conn.Open();

        #region //p2: execute sql statement, get resultset
        OleDbCommand cmd;
        OleDbDataReader dr;
        try
        {
            cmd = new OleDbCommand(sqlstr, conn);
            dr = cmd.ExecuteReader();
        }
        catch (Exception e)
        {

            return e.Message;
        }

        #endregion
        
        //p3: output data in special format
        int colnum = dr.FieldCount;
        if (dr.HasRows == false) return "No available tuple!";

        string str = "";

        while (dr.Read())
        {
            for (int i = 0; i < colnum; i++)
            {
                string s1 = dr.GetValue(i).ToString().Trim();
                str += s1 + ",";
            }
            str += "\n";
        }
        return str;

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sqlstr = tb1.Text;
        if (!sqlstr.Equals(""))
        {
            tb2.Text = runSql2(sqlstr);
        }
    }
}